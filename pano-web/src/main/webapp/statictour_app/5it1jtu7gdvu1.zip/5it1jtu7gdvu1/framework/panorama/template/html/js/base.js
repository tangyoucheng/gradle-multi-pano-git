var hotspot_info = 
{}